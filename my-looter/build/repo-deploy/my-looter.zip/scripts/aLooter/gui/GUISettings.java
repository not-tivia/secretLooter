package scripts.aLooter.gui;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.Property;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextArea;

public class GUISettings {




    public Property<ObservableList<String>> possibleItemsListView;
    public Property<ObservableList<String>> itemsToLootListView;
    public BooleanProperty lootAnyItemOverCheckBox;

    public Property<Integer> lootAnyItemOverSpinner;
    public BooleanProperty minimumStackCheckBox;
    public Property<Integer> minimumStackSpinner;
    public BooleanProperty eatFoodForLootCheckBox;
    public BooleanProperty dropItemsWorthLessCheckBox;
    public BooleanProperty walkAroundAreaCheckBox;
    public Property<Integer> walkAroundAreaSpinner;
    public BooleanProperty ignoreJunkItemsCheckBox;
    public BooleanProperty selectedLocationChoiceBox;
    public Property<Integer> customRadiusSpinner;
    public Property<Integer> customWaitTileRadiusSpinner;


    public StringProperty customExplvMapArea;

    public BooleanProperty emergencyEscapeCollectionAreaCheckBox;
    public BooleanProperty attackMonstersthatAttackUsCheckBox;
    public BooleanProperty attackMonstersFirstCheckBox;
    public StringProperty monsterNameTextField;
    public BooleanProperty escapeFromPkersMethodChoiceBox;
    public Property<Integer> maxWildernessLevelSpinner;
    public BooleanProperty attemptToSafesSpotCheckBox;
    public BooleanProperty escapeFromPkersMethodCheckBox;
    public BooleanProperty alwaysKeepInstantEscapeTabOpenCheckBox;
    public BooleanProperty onlyEscapeIfInteractedCheckBox;
    public BooleanProperty alwaysDisableLeftClickAttackCheckBox;
    public BooleanProperty maxWildernessLevelCheckBox;
    public Property<ObservableList<String>> inventoryListView;
    public Property<ObservableList<String>> equipmentListView;
    public BooleanProperty requiredFoodCheckBox;
    public BooleanProperty requiredFoodChoiceBox;
    public BooleanProperty healingTypeCheckBox;
    public BooleanProperty healingTypeChoiceBox;
    public Property<Integer> hpToEatAtSpinner;
    public Property<Integer> amountOfFoodSpinner;
    public BooleanProperty useEnergyPotionCheckBox;
    public BooleanProperty useAntiPoisonCheckBox;
    public BooleanProperty useAntifireCheckBox;
    public StringProperty itemNameTextField;
    public BooleanProperty lootingMethodChoiceBox;
    public Property<Integer> forceLootSpinner;
    public Property<Integer> automaticallyBankAtSpinner;
    public BooleanProperty teleportUnderAttackCheckbox;
    public BooleanProperty attemptToTelegrabLootOver;
    public BooleanProperty alchItemName;
    // itemnametextfield
    // Alch item name is a checkbox


    public BooleanProperty endScriptIfTellegrabbingMovesUs;
    public BooleanProperty lootingMethodCheckBox;
    public BooleanProperty forceRunForLootCheckBox;
    public BooleanProperty activelyRoamAreaForLootCheckBox;
    public BooleanProperty automaticallyBankAtCheckBox;
    public BooleanProperty cachePlayerCheckBox;
    public BooleanProperty simulateAFKCheckBox;
    public BooleanProperty antibanReactionCheckBox;
    public BooleanProperty bankWhenOutOfFoodCheckBox;
    public BooleanProperty dropEmptyFoodContrainersCheckBox;
    public BooleanProperty bankIfLoseRequiredItemsCheckBox;
    public BooleanProperty endScriptIfWeDieCheckBox;
    public BooleanProperty endScriptIfWeAreMissingRequiredItemsCheckBox;
    public Property<ObservableList<String>> blacklistedItemsListView;
    public StringProperty blacklistTextField;





}
