package scripts.api.listener;

import org.tribot.api2007.types.RSProjectile;

/**
 * Created by willb on 26/07/2018.
 */
public interface ProjectileListener {

	void projectileMoved(RSProjectile projectile);
}
