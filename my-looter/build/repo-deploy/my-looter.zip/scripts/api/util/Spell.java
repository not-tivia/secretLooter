package scripts.api.util;

/**
 * Created by Spencer on 10/8/2017.
 */
public interface Spell {

    boolean isSelected();
    boolean select();
    String getName();

}
