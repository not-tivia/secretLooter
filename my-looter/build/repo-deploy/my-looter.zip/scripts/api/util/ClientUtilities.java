package scripts.api.util;

import org.tribot.api.General;
import org.tribot.script.Script;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.BooleanControl;
import javax.sound.sampled.Line;
import javax.sound.sampled.Mixer;
import javax.swing.*;
import java.awt.*;

/**
 * Created by Fluffee on 03/11/17.
 */
public abstract class ClientUtilities extends Script {

	public static final int FILE_MENU = 0, SCRIPT_MENU = 1, CLIENT_MENU = 2, VIEW_MENU = 3, DEBUG_MENU = 4,
			TOOLS_MENU = 5, HELP_MENU = 6;

	public static void printArrayOneLine(Object... objects) {
		String message = "";
		for (Object object : objects) {
			message = message + object.toString();
		}
		General.println(message);
	}

	/**
	 * Replaces TRiBot Cell Renderer with a custom one to allow for the printing of
	 * colours.
	 *
	 * @param useClientDebug      Boolean flag to indicate if you are replacing the
	 *                            client debug cell renderer or the system debug
	 *                            cell renderer
	 * @param replacementRenderer Replacement ListCellRenderer.
	 */
	public static void replaceCellRenderer(boolean useClientDebug, ListCellRenderer replacementRenderer) {
		int debugValue = useClientDebug ? 1 : 0;
		JFrame tribotFrame = findTRiBotFrame();
		if (tribotFrame == null) {
			General.println("Error, could not find TRiBot Frame. Cannot replace Cell Renderer.");
			return;
		}
		boolean success = true;
		do {
			try {
				JSplitPane tribotSplit = (JSplitPane) tribotFrame.getContentPane().getComponent(0);
				JTabbedPane debug = (JTabbedPane) tribotSplit.getComponent(0);
				JScrollPane clientDebug = (JScrollPane) debug.getComponent(debugValue);
				JViewport viewport = (JViewport) clientDebug.getComponent(0);
				JList list = (JList) viewport.getComponent(0);
				list.setCellRenderer(replacementRenderer);
			} catch (ArrayIndexOutOfBoundsException e) {
				success = false;
			}
		} while (!success);
	}

	/**
	 * Gets default TRiBot list cell renderer so it can be restored later.
	 *
	 * @param useClientDebug Boolean flag to indicate if you are getting the client
	 *                       debug cell renderer or the system debug cell renderer
	 * @return Default cell renderer or null if not able to be found.
	 */
	public static ListCellRenderer getCellRender(boolean useClientDebug) {
		int debugValue = useClientDebug ? 1 : 0;
		JFrame tribotFrame = findTRiBotFrame();
		if (tribotFrame == null) {
			General.println("Error, could not find TRiBot Frame. Cannot replace Cell Renderer.");
			return null;
		}
		JSplitPane tribotSplit = (JSplitPane) tribotFrame.getContentPane().getComponent(0);
		JTabbedPane debug = (JTabbedPane) tribotSplit.getComponent(0);
		JScrollPane clientDebug = (JScrollPane) debug.getComponent(debugValue);
		JViewport viewport = (JViewport) clientDebug.getComponent(0);
		JList list = (JList) viewport.getComponent(0);
		return list.getCellRenderer();
	}

	/**
	 * Resizes split pane to the percentage passed in the arguments.
	 *
	 * @param gameWindowPercentage Percentage to resize split pane to, must be
	 *                             between 0 and 1, with 1 being no debug, and 0
	 *                             being no rs window.
	 * @return Return true if successful, false otherwise.
	 */
	public static boolean resizeSplitPane(double gameWindowPercentage) {
		JFrame tribotFrame = findTRiBotFrame();
		if (tribotFrame == null) {
			General.println("Error, could not find TRiBot Frame. Cannot resize debug.");
			return false;
		}
		if (gameWindowPercentage < 0 || gameWindowPercentage > 1) {
			General.println("Error, percentage argument is not between 0 and 1.");
		}
		JSplitPane tribotSplit = (JSplitPane) tribotFrame.getContentPane().getComponent(0);
		tribotSplit.setDividerLocation(gameWindowPercentage);
		return true;
	}

	/**
	 * Resizes split pane by moving divider to location specified in arguments.
	 *
	 * @param dividerLocation Location to move the divider to.
	 * @return Return true if successful, false otherwise.
	 */
	public static boolean resizeSplitPane(int dividerLocation) {
		JFrame tribotFrame = findTRiBotFrame();
		if (tribotFrame == null) {
			General.println("Error, could not find TRiBot Frame. Cannot resize debug.");
			return false;
		}
		if (dividerLocation < 0) {
			General.println("Error, percentage argument is less than 0.");
		}
		JSplitPane tribotSplit = (JSplitPane) tribotFrame.getContentPane().getComponent(0);
		tribotSplit.setDividerLocation(dividerLocation);
		Component[] components = tribotSplit.getComponents();
		return true;
	}

	/**
	 * Gets the divider location of the split pane.
	 *
	 * @return Returns divider location of split pane, or -1 if an error occurs.
	 */
	public static int getSplitPaneDividerLocation() {
		JFrame tribotFrame = findTRiBotFrame();
		if (tribotFrame == null) {
			General.println("Error, could not find TRiBot Frame. Cannot resize debug.");
			return -1;
		}
		JSplitPane tribotSplit = (JSplitPane) tribotFrame.getContentPane().getComponent(0);
		return tribotSplit.getDividerLocation();
	}

	public static boolean blockUserInput() {
		JMenuItem blockUserInput = getItem(CLIENT_MENU, "Block User Input");
		if (blockUserInput == null) {
			General.println("Error: Could not get button.");
			return false;
		}
		blockUserInput.doClick();
		return true;
	}

	public static JMenu getMenu(int menuNumber) {
		JFrame tribotFrame = findTRiBotFrame();
		if (tribotFrame == null)
			return null;
		JMenuBar tribotMenuBar = tribotFrame.getJMenuBar();
		if (tribotMenuBar == null) {
			General.println("Error: Could not get JMenuBar.");
			return null;
		}
		return tribotMenuBar.getMenu(menuNumber);
	}

	public static JMenu getMenu(int menuNumber, JFrame tribotFrame) {
		JMenuBar tribotMenuBar = tribotFrame.getJMenuBar();
		if (tribotMenuBar == null)
			return null;
		return tribotMenuBar.getMenu(menuNumber);
	}

	public static JMenuItem getItem(int menuNumber, String itemText) {
		JFrame tribotFrame = findTRiBotFrame();
		if (tribotFrame == null)
			return null;
		JMenu menu = getMenu(menuNumber, tribotFrame);
		if (menu == null)
			return null;
		for (int i = 0; i < menu.getItemCount(); i++) {
			JMenuItem item = menu.getItem(i);
			if (item.getText().equals(itemText))
				return item;
		}
		return null;
	}

	/**
	 * Grabs the TRiBot JFrame by the name of the window.
	 *
	 * @return TRiBot JFrame or null if not found.
	 */
	public static JFrame findTRiBotFrame() {
		Frame[] frames = JFrame.getFrames();
		for (Frame tempFrame : frames) {
			if (tempFrame.getTitle().contains("TRiBot")) {
				return (JFrame) tempFrame;
			}
			General.sleep(100);
		}
		General.println("Error, could not find TRiBot Frame.");
		return null;
	}

	public static void findRuntimeFrame() {
		new Thread() {

			public void run() {
				while (true) {
					Window[] frames = findTRiBotFrame().getWindows();
					for (Window tempFrame : frames) {
						System.out.println(tempFrame.getName());
						if (tempFrame.getName().contains("dialog")) {
							//System.out.println(tempFrame.getComponent(0).get getName().toString());
						}
					}
					General.sleep(100);
				}
			}

		}.start();

	}

	/**
	 * Mutes all sound in the TRiBot client.
	 */
	public static void muteSound() {
		Mixer.Info[] infos = AudioSystem.getMixerInfo();
		for (Mixer.Info info : infos) {
			Mixer mixer = AudioSystem.getMixer(info);
			for (Line line : mixer.getSourceLines()) {
				BooleanControl bc = (BooleanControl) line.getControl(BooleanControl.Type.MUTE);
				if (bc != null) {
					bc.setValue(true);
				}
			}
		}
	}

	public static void minimizeClient() {
		findTRiBotFrame().setState(Frame.ICONIFIED);
	}

	public static void maximizeClient() {
		findTRiBotFrame().setState(Frame.NORMAL);
	}

	/**
	 * Unmute sound in the TRiBot client.
	 */
	public static void unmuteSound() {
		Mixer.Info[] infos = AudioSystem.getMixerInfo();
		for (Mixer.Info info : infos) {
			Mixer mixer = AudioSystem.getMixer(info);
			for (Line line : mixer.getSourceLines()) {
				BooleanControl bc = (BooleanControl) line.getControl(BooleanControl.Type.MUTE);
				if (bc != null) {
					bc.setValue(false);
				}
			}
		}
	}

}