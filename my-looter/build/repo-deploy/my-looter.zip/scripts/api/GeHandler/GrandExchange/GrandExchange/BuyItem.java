package scripts.api.GeHandler.GrandExchange.GrandExchange;

import org.tribot.api.General;
import org.tribot.api2007.Inventory;

public class BuyItem {

    /*
    Check for item in inventory/bank
    Check if we have inventory space
    If not in inventory or bank and has same value, then add to shopping list

     */

    public void checkForItems(String item, int amountToHave, boolean stackableItem ){
        /*
        Check inventory and bank for item
        if doesnt have then add to shopping list
         */


    }

    private boolean isAtGE(){
        return true;
    }
 public void purchaseItem(int itemID, int amount, boolean stackableItem ){
   if (isAtGE()){
       General.println("Grand exchange: We are at the Grand exchange.");
        if (Inventory.find(itemID).length > 0){
            if (stackableItem){
                if (Inventory.find(itemID)[0].getStack() >= amount){
                     // All good dont buy any more
                } else {

                }
            }
        }

   } else {
       /*
       Walk to GE
        */
   }
 }

    public boolean buyItem(int AmountToBuy, int PricePerItem, String... Item  ){
        if (isAtGE()){
            General.println("Grand exchange: Already at the GE");
            //if (GrandExchange.isOpen()){

            General.sleep(1500);
            General.println("Grand exchange: GE is open");
            if (Inventory.find(Item[0]).length < 1) {

                    /*
                    if (scripts.progressiveRunecrafter.other_api.util.GrandExchange.hasOfferFor(Item[0])) {
                        General.sleep(1500);
                        General.println("Grand exchange: Checking for existing offer");
                        if (scripts.progressiveRunecrafter.other_api.util.GrandExchange.hasCompleteOffers()) {
                            General.sleep(1500);

                            General.println("Grand exchange: Offer completed");
                            if (scripts.progressiveRunecrafter.other_api.util.GrandExchange.claimAll(METHOD.ITEMS)) {

                                if (Item[0].equals("Amulet of glory(4)")) {
                                    gloryCount = gloryCount + AmountToBuy;
                                }
                                if (Item[0].equals("Varrock teleport")) {
                                    vTabCount = vTabCount + AmountToBuy;
                                }
                                if (Item[0].equals("Falador teleport")) {
                                    fTabCount = fTabCount + AmountToBuy;
                                }
                                if (Item[0].equals("Ring of dueling(8)")) {
                                    rodCount = rodCount + AmountToBuy;
                                }
                                if (Item[0].equals("Lobster")) {
                                    lobsterCount = lobsterCount + AmountToBuy;
                                }
                                if (Item[0].equals("Pure essence")) {
                                    essenceCount = essenceCount + AmountToBuy;
                                }
                                if (Item[0].equals("Mithril pickaxe)")) {
                                    pickCount = pickCount + AmountToBuy;
                                }
                                if (Item[0].equals("Stamina potion(4)")) {
                                    staminaCount = staminaCount + AmountToBuy;
                                }
                                if (Item[0].equals("Adamant scimitar")) {
                                    scimmyCount = scimmyCount + AmountToBuy;
                                }
                                General.println("Grand exchange: Claimed offer");

                            }
                        } else {
                            General.println("Grand exchange: Antiban reaction");
                            Antiban.react();
                        }
                    } else {
                        General.println("Grand exchange: Setting up offer for " + Item[0]);
                        //GrandExchange.setUpOffer(OFFER.BUY, Item[0], AmountToBuy, PricePerItem);
                        org.tribot.api2007.GrandExchange.offer(Item[0], PricePerItem, AmountToBuy, false);
                        General.sleep(1500);
                        if (scripts.progressiveRunecrafter.other_api.util.GrandExchange.hasCompleteOffers()) {
                            General.sleep(1500);

                            General.println("Grand exchange: Offer completed");
                            if (scripts.progressiveRunecrafter.other_api.util.GrandExchange.claimAll(METHOD.ITEMS)){
                                General.sleep(1500);
                            }
                        }
                        //GrandExchange.setUpOffer(OFFER.BUY, Item[0], AmountToBuy, PricePerItem);
                    }
                } else {
                    General.println("Has item in inventory");
                }
            } else {
                if (!GrandExchange.isOpen()){
                    General.println("Grand exchange: Opening GE");
                    GrandExchange.open();
                }

*/

            }
        } else {
            General.println("Grand exchange: Walking to the GE");
            walkToGE();
        }
        return true;
    }


    private void walkToGE(){

    }
}
