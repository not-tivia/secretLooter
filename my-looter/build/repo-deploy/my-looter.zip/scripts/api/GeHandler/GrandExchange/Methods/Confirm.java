package scripts.api.GeHandler.GrandExchange.Methods;

public class Confirm {
}
