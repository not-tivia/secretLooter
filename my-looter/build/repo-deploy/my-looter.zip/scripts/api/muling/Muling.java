package scripts.api.muling;

import org.tribot.script.sdk.query.Query;

public class Muling {

    public static boolean tradeMule(String Mulename){
        return Query.players()
                .nameEquals(Mulename)
                .findFirst()
                .map(mule -> mule.interact("Trade with"))
                .orElse(false);
    }

    public static boolean tradeAccount(String accname){
        return Query.players()
                .nameEquals(accname)
                .findFirst()
                .map(acc -> acc.interact("Trade with"))
                .orElse(false);
    }
}
