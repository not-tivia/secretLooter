package scripts.api.dax_api.shared.helpers.magic;


public interface Validatable {
    boolean canUse();
}
