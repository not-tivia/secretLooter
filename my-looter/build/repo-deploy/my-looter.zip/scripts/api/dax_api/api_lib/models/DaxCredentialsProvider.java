package scripts.api.dax_api.api_lib.models;

@FunctionalInterface
public interface DaxCredentialsProvider {
    DaxCredentials getDaxCredentials();
}
