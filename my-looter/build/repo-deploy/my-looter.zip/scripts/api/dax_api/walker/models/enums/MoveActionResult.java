package scripts.api.dax_api.walker.models.enums;

public enum MoveActionResult {
    SUCCESS,
    FAILED,
    FATAL_ERROR
}
