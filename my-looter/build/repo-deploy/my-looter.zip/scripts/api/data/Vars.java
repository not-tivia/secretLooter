package scripts.api.data;

import org.tribot.api.General;
import org.tribot.api2007.Skills;
import org.tribot.api2007.types.RSTile;

import static scripts.api.data.Constants.gainedfromPrayer;

public class Vars {


    public static Vars vars;

    public static Vars get() {
        return vars == null ? vars = new Vars() : vars;
    }

    public void reset() {
        vars = new Vars();
    }

    public boolean continueRunning = true;
    public boolean debug = true;
    public static final long START_TIME = System.currentTimeMillis();
    public boolean trainingMode = true;

    //Questing
    public String currentTask;
    public String currentSubTask;



    //Gear checks
    public int helmID;
    public int bodyID;
    public int legID;
    public int weaponID;
    public int shieldID;


    public boolean trainingDefense;
   

   //Storing trainer values
    public int strength1 = 0;
    public int strength2 = 0;
    public int strength3 = 0;
    public int strength4 = 0;
    public int attack1 = 0;
    public int attack2 = 0;
    public int attack3 = 0;
    public int attack4 = 0;

    public int strengthEndLevel = 0;
    public int attackEndLevel = 0;
    public boolean needsToClaim = false;
    public RSTile CLAIM_POSITION;
    public double CLAIM_TIME;





    public boolean onstartCheckCompleted = false;



    public String fightType;


    public boolean trainingAreaDecided = false;

    public boolean needsToBreak = false;
    public RSTile safeTile = null;

    public long time = System.currentTimeMillis();

    //General combat
    public boolean foodFound = false;
    public boolean MULTICOMBATAREA = false;
    public boolean alchDecision = false;
    public int foodID = 0;
    public boolean gemBagDecision = false;
    public boolean herbSackDecision = false;
    public boolean soulbearerDecision = false;
    public boolean guthansDecision = false;
    public boolean sgsDecision = false;
    public boolean isUsingCannon = false;
    public boolean usingSupers = false;
    public boolean usingPpots = false;


    //Timing kills
    public int amountKilled;
    public int averageKillTime;
    public long killStartTime;
    public long killEndTime;
    public long timeToKill;

    public int CHANGE_TIME = General.random(480000, 2700000);
    public long LAST_CHANGE = System.currentTimeMillis();

    //Slayer
    
    public boolean hasSlayerTask = false;
    public boolean shouldCheckTask = false;

    //Cannon related stuff
    public boolean reloadCannnonNow = false;
    public boolean hascannonBalls = false;
    public boolean hasCannon = false;
    public boolean refillCannon = false;


    public double lessthanmaxPrayer = Skills.SKILLS.PRAYER.getActualLevel() - gainedfromPrayer;

    //General questing
    public boolean isQuesting = false;
    public boolean hasBankedOnStart = false;

    //witches potion
    public boolean witchesPotionQuest = false;
    public boolean witchHasRatTail = false;
    public boolean witchKilledGiantRat = false;
    public boolean witchBurntMeat = false;
    public boolean witchEyeOfNewt = false;
    public boolean witchHasOnion = false;
    public boolean witchHasTalkedToWitch;

    //Imp catcher
    public boolean hasAllBeads = false;
    public boolean impCatcherQuest = false;
    public boolean hasTalkToWizard = false;
    public boolean hasNecklaceOfPassage = false;

    //vampire slayer
    public boolean vampireSlayerQuest = false;
    public boolean hasTalkedToNed = false;
    public boolean hasHammer = false;
    public boolean hasBeer = false;
    public boolean hasGarlic = false;
    public boolean hasStake = false;
    public boolean hasDespawned = false;
    public boolean hasOpenedCoffin = false;
    public boolean hasFood = false;
    public boolean hasMagicGear = false;
}
