package scripts.api.data;

import org.tribot.api2007.GroundItems;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.Skills;
import org.tribot.api2007.types.*;

public class Constants {

    //Dax walker keys
    public final static String apiKey = "sub_DPjXXzL5DeSiPf";
    public final static String secretKey =  "PUBLIC-KEY";

    //Memes
    public final static String main = "[Main] ";
    public final static String antiban = "[AnTiBaN] ";

    //Animations that dont change
    public final static int EATING_ANIMATION = 829;


    //Monster locations
    public final static RSArea CATACOMB_ANKOUS = new RSArea(new RSTile(1635, 9990, 0), new RSTile(1645, 9998, 0));
    public final static double gainedfromPrayer = 7 + Math.floor(Skills.SKILLS.PRAYER.getActualLevel() / 4);

    public final static RSArea STRONGHOLD_ANKOUS = new RSArea(new RSTile(2471, 9807, 0), new RSTile(2481, 9897, 0));
    public final static RSArea AreaStrongholdAberrantSpectre = new RSArea(new RSTile(2461, 9787, 0), new RSTile(2450, 9796, 0));
    public final static RSArea areaSeagulls = new RSArea(new RSTile(3022, 3209, 0), new RSTile(3036, 3195, 0));

    public final static RSArea WITCHS_POTION = new RSArea(new RSTile(2965, 3208, 0), new RSTile(2970, 3203, 0));
    public final static RSArea RATS_TAIL = new RSArea(new RSTile(2953, 3205, 0), new RSTile(2960, 3202, 0));
    public final static RSArea ONION_FIELD = new RSArea(new RSTile(2946, 3253, 0), new RSTile(2955, 3247, 0));
    public final static RSArea RAW_RAT_MEAT = new RSArea(new RSTile(3008, 3186, 0), new RSTile(2985, 3204, 0));
    public final static RSArea WITCHS_RANGE = new RSArea(new RSTile(2965, 3213, 0), new RSTile(2970, 3209, 0));
    public final static RSArea TRAINING_INSTRUCTOR = new RSArea(
            new RSTile[] {
                    new RSTile(3211, 3240, 0),
                    new RSTile(3219, 3244, 0),
                    new RSTile(3225, 3235, 0),
                    new RSTile(3215, 3235, 0)
            }
    );
    public final static RSArea areaFallyCows = new RSArea(
            new RSTile[] {
                    new RSTile(3021, 3312, 0),
                    new RSTile(3021, 3297, 0),
                    new RSTile(3032, 3297, 0),
                    new RSTile(3033, 3298, 0),
                    new RSTile(3038, 3298, 0),
                    new RSTile(3038, 3297, 0),
                    new RSTile(3041, 3297, 0),
                    new RSTile(3044, 3300, 0),
                    new RSTile(3044, 3312, 0),
                    new RSTile(3041, 3314, 0),
                    new RSTile(3023, 3314, 0)
            }
    );
    public final static RSArea areaAdventureJon = new RSArea(new RSTile(3231, 3232, 0), new RSTile(3234, 3235, 0));
    public final static RSArea areaLumbridgeGoblins = new RSArea(new RSTile(3240, 3242, 0), new RSTile(3263, 3227, 0));
    public final static RSArea areaKalphiteWorkers = new RSArea(new RSTile(3318, 9508, 0), new RSTile(3331, 9496, 0));
    public final static RSArea areaHobgoblins = new RSArea(
            new RSTile[] {
                    new RSTile(2904, 3295, 0),
                    new RSTile(2911, 3277, 0),
                    new RSTile(2914, 3279, 0),
                    new RSTile(2908, 3299, 0)
            }
    );
    public final static RSArea areaGhouls = new RSArea(new RSTile(3438, 3457, 0), new RSTile(3424, 3470, 0));
    public final static RSArea areaHillGiants = new RSArea(
            new RSTile[] {
                    new RSTile(3111, 9848, 0),
                    new RSTile(3121, 9851, 0),
                    new RSTile(3123, 9829, 0),
                    new RSTile(3103, 9825, 0),
                    new RSTile(3098, 9833, 0)
            }
    );
    public final static RSArea areaFlesh1 = new RSArea(new RSTile(2046, 5185, 0), new RSTile(2038, 5193, 0));
    public final static RSArea areaFlesh2 = new RSArea(new RSTile(2000, 5207, 0), new RSTile(2011, 5198, 0));
    public final static RSArea areaFlesh3 = new RSArea(new RSTile(1987, 5243, 0), new RSTile(1996, 5232, 0));

    public final static String[] herbs = {"Grimy ranarr weed", "Grimy avantoe", "Grimy snapdragon", "Grimy torstol", "Grimy dwarf weed", "Grimy lantadyme", "Grimy cadantine", "Grimy kwuarm", "Grimy irit leaf", "Grimy toadflax"};
    public final static String[] gems = {"Uncut ruby", "Uncut sapphire", "Uncut emerald", "Uncut diamond", "Uncut dragonstone"};
    public final static RSGroundItem[] expensive = GroundItems.findNearest("Abyssal whip");
    public final static RSItem[] enchantedGem = Inventory.find("Enchanted gem");
    public final static RSItem[] slayerHelm = Inventory.find("Slayer helm");


    public static int	SPELLBOOK_SETTING_VAR = 4070,
            STANDARD_SPELLBOOK_VALUE = 0,
            ANCIENT_SPELLBOOK_VALUE = 1,
            LUNAR_SPELLBOOK_VALUE = 2,
            ARCEUUS_SPELLBOOK_VALUE = 3;


    public static boolean isOnStandardSpellbook(){
        return RSVarBit.get(SPELLBOOK_SETTING_VAR).getValue() == STANDARD_SPELLBOOK_VALUE;
    }
    public static boolean isOnArceuusSpellbook(){
        return RSVarBit.get(SPELLBOOK_SETTING_VAR).getValue() == ARCEUUS_SPELLBOOK_VALUE;
    }
    public static boolean isOnAncientSpellbook(){
        return RSVarBit.get(SPELLBOOK_SETTING_VAR).getValue() == ARCEUUS_SPELLBOOK_VALUE;
    }
    public static boolean isOnLunarSpellbook() {
        return RSVarBit.get(SPELLBOOK_SETTING_VAR).getValue() == LUNAR_SPELLBOOK_VALUE;
    }






}
