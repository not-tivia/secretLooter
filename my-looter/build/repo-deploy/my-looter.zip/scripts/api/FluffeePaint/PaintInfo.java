package scripts.api.FluffeePaint;

/**
 * Created by Fluffee on 09/01/18.
 */
public interface PaintInfo {

    public String[] getPaintInfo();

}
