package scripts.api.rsitem_services.grand_exchange_api;

import com.allatori.annotations.DoNotRename;

/**
 *
 */
@DoNotRename
class PriceTrend
{
    @DoNotRename
    public String trend;
    @DoNotRename
    public int price;
}
