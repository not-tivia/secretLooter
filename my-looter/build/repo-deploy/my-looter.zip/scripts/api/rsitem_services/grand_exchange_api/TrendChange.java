package scripts.api.rsitem_services.grand_exchange_api;

import com.allatori.annotations.DoNotRename;

/**
 *
 */
@DoNotRename
class TrendChange
{
    @DoNotRename
    public String trend, change;
}
