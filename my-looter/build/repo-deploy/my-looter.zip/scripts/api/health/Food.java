package scripts.api.health;

public class Food {

    public final static int EATING_ANIMATION = 829;
}
