package scripts.api.health;

import org.tribot.api2007.Skills;

public class Hitpoints {

    public static int getHpPercent() {
        return (Skills.getCurrentLevel(Skills.SKILLS.HITPOINTS) * 100) / Skills.getActualLevel(Skills.SKILLS.HITPOINTS);
    }

}
