package scripts.api.gearmanager;

import org.tribot.api2007.Equipment;
import org.tribot.api2007.types.RSItem;


public class gear {

    public static boolean equip( String itemName, Equipment.SLOTS gearSlot, boolean buyFromGE) {


        RSItem[] equipment_tab = Equipment.find(itemName);
        if (equipment_tab.length < 1){
            //if (h)

        } else {
            return true;
        }

        return false;
    }
}
