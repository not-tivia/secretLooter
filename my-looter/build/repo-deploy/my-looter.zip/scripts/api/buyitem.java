package scripts.api;

import org.tribot.api.General;
import org.tribot.api2007.Player;
import org.tribot.api2007.types.*;
import scripts.api.GrandExchange.METHOD;
import scripts.api.GrandExchangeSnippet.Exchange;
import scripts.api.antiban.Antiban;
import scripts.api.dax_api.api_lib.DaxWalker;
import scripts.api.entityselector.Entities;
import scripts.api.entityselector.finders.prefabs.InterfaceEntity;
import scripts.api.entityselector.finders.prefabs.ObjectEntity;



public class buyitem {


    RSObject spinner = Entities.find(ObjectEntity::new)

            .actionsEquals("Spin")
            .sortByDistance()
            .getFirstResult();

    RSInterface buyitem = Entities.find(InterfaceEntity::new)
            .inMaster(465)
            .textureIdEquals(1108)
            .getFirstResult();

    RSInterface sellitem = Entities.find(InterfaceEntity::new)
            .inMaster(465)
            .textureIdEquals(1106)
            .getFirstResult();


    //is at GE

    public RSArea gearea = new RSArea(
            new RSTile(3160, 3493, 0),
            new RSTile(3169, 3486, 0)
    );


    private boolean isAtGE(){
        return (Player.getPosition() == null || gearea == null) ? false : gearea.contains(Player.getPosition());
    }
    //has required items

    public String getItemNameFromID(int itemID){
        RSItemDefinition itemDef  = RSItemDefinition.get(itemID);
        if(itemDef !=null){
            String itemName = itemDef.getName();
            if(itemName!=null){
                return itemName;
            }
        }
        return "";
    }

    //isopen
    //place offer
    //has offer for
    //has completed offer
    /// claim

    public static void buy2(int AmountToBuy, int PricePerItem, int... Item  ) {
        if (Exchange.isOpen()) {
            if (scripts.api.util.GrandExchange.hasOfferFor(Item[0])) {
                if (scripts.api.util.GrandExchange.hasCompleteOfferFor(Item[0])) {
                    if (scripts.api.util.GrandExchange.claimAll(METHOD.ITEMS)) {
                        //remove from list
                        General.sleep(2000,5000);
                        General.println("claimed items");
                    }
                } else {
                    //wait for offer to complete
                    Antiban.get().performReactionTimeWait();
                }
            } else {
                //place ge offer
              if (Exchange.offer(Item[0], PricePerItem, AmountToBuy, true)){
                  General.sleep(2000,5000);
                  General.println("placed ge offer");
              }
            }
        } else {
            //open ge
            Exchange.open();
            General.sleep(2000,5000);
            General.println("open ge");
        }
    }

    public static void sell2(int AmountToSell, int PricePerItem, int... Item  ) {
        if (Exchange.isOpen()) {
            if (scripts.api.util.GrandExchange.hasOfferFor(Item[0])) {
                if (scripts.api.util.GrandExchange.hasCompleteOfferFor(Item[0])) {
                    if (scripts.api.util.GrandExchange.claimAll(METHOD.ITEMS)) {
                        //remove from list
                        General.sleep(2000,5000);
                        General.println("claimed items");
                    }
                } else {
                    //wait for offer to complete
                    Antiban.get().performReactionTimeWait();
                }
            } else {
                //place ge offer
                if (Exchange.offer(Item[0], PricePerItem, AmountToSell, false)){
                    General.sleep(2000,5000);
                    General.println("placed ge offer");
                }
            }
        } else {
            //open ge
            Exchange.open();
            General.sleep(2000,5000);
            General.println("open ge");
        }
    }





    private boolean walkToGE() {
        return DaxWalker.walkTo(gearea.getRandomTile());
    }



}
