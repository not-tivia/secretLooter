package scripts.api.bank;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.*;
import org.tribot.api2007.types.RSInterface;
import org.tribot.api2007.types.RSItem;
import org.tribot.api2007.types.RSNPC;
import org.tribot.api2007.types.RSObject;
import scripts.api.dax_api.api_lib.DaxWalker;
import scripts.api.dax_api.api_lib.models.RunescapeBank;


public class bank {

    public static boolean bankHasItem(String... ItemName) {
        RSItem[] items = Banking.find(ItemName);
        return items.length > 0 && items[0] != null;
    }


    public final static boolean isAtBank() {
        RSObject[] bank = Objects.findNearest(5, "Bank booth", "Bank chest", "Bank Booth", "Open chest");
        RSNPC[] banker = NPCs.findNearest("Banker");
        return bank.length > 0 && bank[0] != null;
    }


    public void withdrawFromBank(int withdrawAmount, int itemID, boolean noteItems, boolean stopScript, RunescapeBank bankName) {
        RSItem[] item = Banking.find(itemID);
        RSItem[] inventoryHasItem = Inventory.find(itemID);
        int withdrawID;

        if (inventoryHasItem.length < 1) {
            if (isAtBank()) {
                if (Banking.isBankScreenOpen()) {
                    if (item.length > 0) {
                        if (noteItems) {
                            if (Game.getSetting(115) != 1) {
                                RSInterface noteButton = Interfaces.get(12, 24);
                                if (noteButton != null) {
                                    if (noteButton.click())
                                        Timing.waitCondition(() -> Game.getSetting(115) == 1, General.random(1500, 2000));
                                }
                            }
                            withdrawID = itemID + 1;
                        } else {
                            withdrawID = itemID;
                        }
                        if (Banking.withdraw(withdrawAmount, withdrawID)) {
                            Timing.waitCondition(() -> inventoryHasItem.length > 0, General.random(1500, 2000));
                        }
                    } else {
                        General.println("Out of supplies");
                        if (stopScript) {
                           // stopScript();
                        } else {
                            //restock
                        }
                    }
                } else {
                    if (Banking.openBank()) {
                        Timing.waitCondition(() -> Banking.isBankScreenOpen(), General.random(2500, 4100));
                    }
                }
            } else {
                if (bankName.equals(RunescapeBank.EDGEVILLE)) {
                    General.println("Using nearest bank");
                    if (DaxWalker.walkToBank()) {
                        Timing.waitCondition(() -> !Player.isMoving(), General.random(2500, 4100));
                    }
                } else {
                    if (DaxWalker.walkToBank(bankName)) {
                        Timing.waitCondition(() -> !Player.isMoving(), General.random(2500, 4100));
                    }
                }
            }
        }


    }


}
