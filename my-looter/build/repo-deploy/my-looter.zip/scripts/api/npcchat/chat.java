package scripts.api.npcchat;

import org.tribot.api.Clicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Keyboard;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.NPCChat;
import org.tribot.api2007.types.RSInterface;
import scripts.api.entityselector.Entities;
import scripts.api.entityselector.finders.prefabs.InterfaceEntity;

import java.awt.event.KeyEvent;
import java.util.Arrays;

public class chat {
    /*
    231 is noew nopc chat?
     */


    public static final int RECEIVED_ITEMS_INTERFACE = 11, ITEM_ACTION_INTERFACE_WINDOW = 193,
            PLAYER_TALKING_INTERFACE_WINDOW = 217, SINGLE_OPTION_DIALOGUE_WINDOW = 229,
            NPC_TALKING_INTERFACE_WINDOW = 231, LEVEL_UP_INTERFACE_WINDOW = 233,
            IN_CHAT_INTERFACE = 561, NPC_OPTIONS_INTERFACES = 219;


    public static boolean isChatOpen(){
        String npcOptions[] = NPCChat.getOptions();
        String npcMessage = NPCChat.getMessage();
        RSInterface clickContinue = NPCChat.getClickContinueInterface();
        return Interfaces.isInterfaceSubstantiated(RECEIVED_ITEMS_INTERFACE) || Interfaces.isInterfaceSubstantiated(ITEM_ACTION_INTERFACE_WINDOW) ||
                Interfaces.isInterfaceSubstantiated(PLAYER_TALKING_INTERFACE_WINDOW) || Interfaces.isInterfaceSubstantiated(SINGLE_OPTION_DIALOGUE_WINDOW) ||
                Interfaces.isInterfaceSubstantiated(NPC_TALKING_INTERFACE_WINDOW) ||Interfaces.isInterfaceSubstantiated(LEVEL_UP_INTERFACE_WINDOW) ||
                Interfaces.isInterfaceSubstantiated(IN_CHAT_INTERFACE) ||
                Interfaces.isInterfaceSubstantiated(NPC_OPTIONS_INTERFACES) || npcOptions!=null || npcMessage!=null || Interfaces.isInterfaceSubstantiated(clickContinue);

    }
    public static boolean isChatOpenOLD(){
        String npcOptions[] = NPCChat.getOptions();
        RSInterface chatOption = Interfaces.get(219,1);
        RSInterface emptyChat = Interfaces.get(193,0,2);
        String npcMessage = NPCChat.getMessage();
        RSInterface clickContinue = NPCChat.getClickContinueInterface();
        return npcOptions!=null || Interfaces.isInterfaceSubstantiated(chatOption) || Interfaces.isInterfaceSubstantiated(emptyChat) || npcMessage!=null || Interfaces.isInterfaceSubstantiated(clickContinue);
    }


    /*
    npcChooseOption
    npcCutScene
    npcAcceptItem
    npcChatUntil

     */



    public static boolean npcChooseOption(String containsText, int clickingType){
        String options[] = NPCChat.getOptions();
        if (options!=null){
            for (String s : options) {
                if (s.contains(containsText)) {
                    if (clickingType == 1) {
                        General.println("Clicking chat option: " + s);
                        if (NPCChat.selectOption(s, true)) {
                            Timing.waitCondition(() -> !s.contains(containsText), General.random(2300, 3100));
                        }
                    } else {
                        int arrayValue = Arrays.asList(options).indexOf(s) + 1;
                        General.println("Using keyboard to press: " + s + " which is option " + arrayValue);
                        Keyboard.typeSend(Integer.toString(arrayValue));
                        Timing.waitCondition(() -> !s.contains(containsText), General.random(2300, 3100));
                    }
                }
            }
        } else {
            RSInterface selection = Entities.find(InterfaceEntity::new)
                    .inMasterAndChild(219)
                    .textContains(containsText)
                    .getFirstResult();
            RSInterface selection2 = Entities.find(InterfaceEntity::new)
                    .inMasterAndChild(231)
                    .textContains(containsText)
                    .getFirstResult();
            RSInterface selection3 = Entities.find(InterfaceEntity::new)
                    .inMasterAndChild(229)
                    .textContains(containsText)
                    .getFirstResult();

            if (Interfaces.isInterfaceSubstantiated(selection)) {
                if (Clicking.click(selection)){
                    General.sleep(700,1200);
                }
            } else {
                if (Interfaces.isInterfaceSubstantiated(selection2)){
                    if (Clicking.click(selection2)){
                        General.sleep(700,1200);
                    }
                } else {
                    if (Interfaces.isInterfaceSubstantiated(selection2)){
                        if (Clicking.click(selection3)){
                            General.sleep(700,1200);
                        }
                    } else {
                        RSInterface clickContinue = NPCChat.getClickContinueInterface();
                        if (clickContinue!=null) {
                            General.println("Pressing spacebar until we find: " + containsText);
                            Keyboard.sendPress(KeyEvent.CHAR_UNDEFINED, KeyEvent.VK_SPACE);
                            Timing.waitCondition(() -> !Interfaces.isInterfaceSubstantiated(clickContinue), General.random(2300, 3100));
                        }
                    }
                }
            }
        }
        return false;
    }


    public boolean chooseOpen(String desiredText, int clickingType){
        /*
        First we will search for NPC chat
        Them we will search for interface 219,1
        Then we will check if an empty chat interface is open (such as when you hand an item over in a cutscene
         */
        String options[] = NPCChat.getOptions();
        if (options!=null){
            for (String s : options) {
                if (s.contains(desiredText)) {
                    if (clickingType == 1) {
                        General.println("Clicking " + s);
                        if (NPCChat.selectOption(s, true)) {
                            Timing.waitCondition(() -> !s.contains(desiredText), General.random(2300, 3100));
                        }
                    } else {
                        int arrayValue = Arrays.asList(options).indexOf(s) + 1;
                        General.println("Using keyboard to press: " + s + " which is option " + arrayValue);
                        Keyboard.typeSend(Integer.toString(arrayValue));
                        Timing.waitCondition(() -> !s.contains(desiredText), General.random(2300, 3100));
                    }
                }
            }
        } else {
            RSInterface selection = Entities.find(InterfaceEntity::new)
                    .inMasterAndChild(219,1)
                    .textContains(desiredText)
                    .getFirstResult();
            if (Interfaces.isInterfaceSubstantiated(selection)) {
                if (Clicking.click(selection)){
                    General.sleep(700,1200);
                }
            }
        }
        return false;

    }

    public static void selectMessage(String message, int interfaceMaster){

        RSInterface selection = Entities.find(InterfaceEntity::new)
                .inMaster(interfaceMaster)

               .textEquals(message)
                .getFirstResult();

        if (Interfaces.isInterfaceSubstantiated(selection)) {
            if (Clicking.click(selection)){
                Timing.waitCondition(() -> !Interfaces.isInterfaceSubstantiated(selection), General.random(600, 1300));
            }
        }
    }

    public final static void handleInterfaces(){
        RSInterface click = Entities.find(InterfaceEntity::new)
                .textContains("Click here to continue")
                .getFirstResult();

        if (click!=null){
            if (Clicking.click(click)){
                Timing.waitCondition(() -> click!=null, General.random(1200, 2100));
            }
        }
    }

    public static void chooseOptionInterfaceSelector(int Master, int child, String desiredText){
        RSInterface selection = Entities.find(InterfaceEntity::new)
                .inMasterAndChild(Master, child)
                .textContains(desiredText)
                .getFirstResult();
        if (Interfaces.isInterfaceSubstantiated(selection)) {
            if (Clicking.click(selection)){
                General.sleep(700,1200);
            }
        }
    }
    public static void npcChatChooseOption(String desiredText, int clickingType) {
        String options[] = NPCChat.getOptions();
        if (options != null) {
            for (String s : options) {
                if (s.contains(desiredText)) {
                    if (clickingType == 1) {
                        General.println("Clicking " + s);
                        if (NPCChat.selectOption(s, true)) {
                            Timing.waitCondition(() -> !s.contains(desiredText), General.random(2300, 3100));
                        }
                    } else {
                        int arrayValue = Arrays.asList(options).indexOf(s) + 1;
                        General.println("Using keyboard to press: " + s + " which is option " + arrayValue);
                        Keyboard.typeSend(Integer.toString(arrayValue));
                        Timing.waitCondition(() -> !s.contains(desiredText), General.random(2300, 3100));
                    }
                }
            }
        } else {
            RSInterface clickContinue = NPCChat.getClickContinueInterface();
            if (clickContinue!=null) {
                General.println("Pressing spacebar");
                Keyboard.sendPress(KeyEvent.CHAR_UNDEFINED, KeyEvent.VK_SPACE);
                Timing.waitCondition(() -> !Interfaces.isInterfaceSubstantiated(clickContinue), General.random(2300, 3100));
            }
        }
    }

    public static boolean npcChatContainsFailsafe(String desiredText) {
        String options[] = NPCChat.getOptions();
        if (options == null) {
            return false;
        } else {
            for (String s : options) {
                if (s.contains(desiredText)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean npcChatUntil(String containsText) {
        String chosenText = NPCChat.getMessage();
        RSInterface clickContinue = NPCChat.getClickContinueInterface();
        if (chosenText != null) {
            System.out.println(chosenText);
            if (chosenText.contains(containsText)) {
                General.println("Our desired text is " + containsText);
                Keyboard.sendPress(KeyEvent.CHAR_UNDEFINED, KeyEvent.VK_SPACE);
                Timing.waitCondition(() -> !Interfaces.isInterfaceSubstantiated(clickContinue), General.random(2300, 3100));
                return true;
            } else {
                Keyboard.sendPress(KeyEvent.CHAR_UNDEFINED, KeyEvent.VK_SPACE);
                Timing.waitCondition(() -> !Interfaces.isInterfaceSubstantiated(clickContinue), General.random(2300, 3100));
                return false;
            }
        }
        return false;
    }

    public static boolean npcChatUntilCutscene(String desiredText, int min, int max) {
        String chosenText = NPCChat.getMessage();
        RSInterface clickContinue = NPCChat.getClickContinueInterface();
        if (chosenText != null) {
            if (chosenText.contains(desiredText)) {
                General.println("Our desired text is " + desiredText);
                Keyboard.sendPress(KeyEvent.CHAR_UNDEFINED, KeyEvent.VK_SPACE);
                General.sleep(min,max);
                return true;
            } else {
                Keyboard.sendPress(KeyEvent.CHAR_UNDEFINED, KeyEvent.VK_SPACE);
                Timing.waitCondition(() -> !Interfaces.isInterfaceSubstantiated(clickContinue), General.random(2300, 3100));
                return false;
            }
        }
        return false;
    }


    public static boolean npcChatChooseOption2(String desiredText, int clickingType) {
        String options[] = NPCChat.getOptions();
        if (options != null) {
            for (String s : options) {
                if (s.contains(desiredText)) {
                    if (clickingType == 1) {
                        General.println("Clicking " + s);
                        if (NPCChat.selectOption(s, true)) {
                            Timing.waitCondition(() -> !s.contains(desiredText), General.random(2300, 3100));
                            return true;
                        }
                    } else {
                        int arrayValue = Arrays.asList(options).indexOf(s) + 1;
                        General.println("Using keyboard to press: " + s + " which is option " + arrayValue);
                        Keyboard.typeSend(Integer.toString(arrayValue));
                        Timing.waitCondition(() -> !s.contains(desiredText), General.random(2300, 3100));
                        return true;
                    }
                }
            }
        }
        return false;
    }


}
