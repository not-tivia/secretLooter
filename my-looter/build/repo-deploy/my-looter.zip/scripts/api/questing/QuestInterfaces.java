package scripts.api.questing;

import org.tribot.api.Clicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.types.RSInterface;

public class QuestInterfaces {



    /*
    Close interface ID
     */
    public static boolean closeQuestCompletedInterface(){
        RSInterface questcomplete = Interfaces.get(153, 16);

        if (Interfaces.isInterfaceSubstantiated(questcomplete)) {
            if (Clicking.click(questcomplete)) {
                Timing.waitCondition(() -> !Interfaces.isInterfaceSubstantiated(questcomplete), General.random(2300, 3100));
                return true;
            }
        }
        return false;
    }

}
