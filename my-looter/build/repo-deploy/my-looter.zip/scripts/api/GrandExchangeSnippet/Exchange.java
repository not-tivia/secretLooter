package scripts.api.GrandExchangeSnippet;


import org.tribot.api.Clicking;
import org.tribot.api.General;
import org.tribot.api.Screen;
import org.tribot.api.Timing;
import org.tribot.api.input.Keyboard;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.NPCs;
import org.tribot.api2007.types.RSInterface;
import org.tribot.api2007.types.RSItem;
import org.tribot.api2007.types.RSNPC;

import java.awt.event.KeyEvent;

// ORIGINAL CREDITS TO NEURO - https://tribot.org/forums/topic/78027-snippets-neuros-ge-api/
// CHANGED BROKEN INTERFACEIDS


public class Exchange {

	public static boolean offer(int itemID, int price, int quantity, boolean buy) {
		String name = InfoHelper.getItemNameFromID(itemID);
		if(name == null) return false;
		switch(getOfferState(itemID, price, quantity, buy)) {
		case GE_CLOSED:
			open();
			General.sleep(250,400);
			break;
		case HISTORY_SCREEN:
			exitHistoryScreen();
			General.sleep(250,400);
			break;
		case LOADING_SCREENS:
			General.sleep(300,600);
			break;
		case OFFER_SCREEN_ITEM_WRONG:
			//General.println("item wrong");
			handleWrongOfferItem(name, itemID, buy);
			General.sleep(250,400);
			break;
		case OFFER_SCREEN_OFFER_CORRECT:
			if(GEInterfaces.CONFIRM_NEW_OFFER.get().click())
				Timing.waitCondition(GEConditions.GESelectionWindowVisible(), General.random(4000, 7000));
			General.sleep(250,400);
			break;
		case OFFER_SCREEN_PRICE_WRONG:
			handleWrongOfferPrice(price, buy);
			General.sleep(750, 1000);
			break;
		case OFFER_SCREEN_QUANTITY_WRONG:
			handleWrongOfferQuantity(quantity);
			General.sleep(750, 1000);
			break;
		case OFFER_SCREEN_TYPE_WRONG:
			if(GEInterfaces.BACK_BTN.get().click())
				Timing.waitCondition(GEConditions.GESelectionWindowVisible(), General.random(4000, 7000));
			General.sleep(250,400);
			break;
		case SELECTION_SCREEN_CAN_COLLECT:
			if(GEInterfaces.COLLECT_BTN.get().click())
				Timing.waitCondition(GEConditions.hasCollected(), General.random(4000, 7000));
			General.sleep(250,400);
			break;
		case SELECTION_SCREEN_CAN_MAKE_OFFER:
			handleMakingOffer(name, buy);
			General.sleep(600,1200);
			break;
		case SELECTION_SCREEN_OFFER_ACTIVE:
			return true;
		case SELECTION_SCREEN_SHOULD_CANCEL_OFFER:
			handleCancellingOffer();
			General.sleep(400,700);
			break;
		case SELECTION_SCREEN_SHOULD_RETURN_TRUE:
			return true;
		case SELECTION_SCREEN_SHOULD_WAIT:
			General.sleep(3000, 6000);
			break;
		}
		
		return offer(itemID, price, quantity, buy);
	}
	
	public static OfferState getOfferState(int itemID, int price, int quantity, boolean buy) {
		if(isOpen()) {
			//The GE is open, what window are we on?
			if(GEInterfaces.SELECTION_WINDOW.isVisible()) {
				//We are on the selection window.
				for(int i = 7; i < 15 ; i++) {
					//Do we already have an offer of this item?
					RSInterface item = Interfaces.get(465, i, 18);
					if(item != null && !item.isHidden()) {
						if(item.getComponentItem() == itemID) {
							//Yes we do, is it the right type?
							RSInterface type = Interfaces.get(465, i, 16);
							if(type != null && !type.isHidden()) {
								if(type.getText().contains("Buy")) {
									if(buy == true) {
										//Yes it is, return we have made the offer.
										return OfferState.SELECTION_SCREEN_OFFER_ACTIVE;
									}
								} else {
									if(buy == false) {
										//Yes it is, return we have made the offer.
										return OfferState.SELECTION_SCREEN_OFFER_ACTIVE;
									}
								}
							}
						}
					}
				}	
				//No we don't already have an active offer
				for(int b = 7; b < 15 ; b++) {
					//Do we have an empty offer slot?
					RSInterface type = Interfaces.get(465, b, 16);
					if(type != null && !type.isHidden()) {
						if(type.getText().contains("Empty")) {
							//Yes we do, return we can make the offer
							return OfferState.SELECTION_SCREEN_CAN_MAKE_OFFER;
						}
					}
				}
				//No we don't, do we have any offers to collect?
				if(GEInterfaces.COLLECT_BTN.isVisible()) {
					//Yes we do, return we can collect offers
					return OfferState.SELECTION_SCREEN_CAN_COLLECT;
				}
						
				//No we don't, should we cancel an offer?
				if(buy == true) {
					//Check if there is a sell offer to cancel
					for(int c = 7; c < 15 ; c++) {
						RSInterface type = Interfaces.get(465, c, 16);
						if(type != null && !type.isHidden()) {
							if(type.getText().contains("Sell")) {
								//Yes there is, return we can abort a sell offer.
								return OfferState.SELECTION_SCREEN_SHOULD_CANCEL_OFFER;
							}
						}
					}
					
					//No there isn't, we should wait because we are trying to buy something
					return OfferState.SELECTION_SCREEN_SHOULD_WAIT;
				} else {
					return OfferState.SELECTION_SCREEN_SHOULD_RETURN_TRUE;
				}
			} else if(GEInterfaces.CONFIRM_NEW_OFFER.isVisible()) {
				//We are on an offer screen, check that it is the right type
				if(GEInterfaces.BUY_WINDOW.isVisible())
					if(buy == false)
						return OfferState.OFFER_SCREEN_TYPE_WRONG;
				
				if(GEInterfaces.SELL_WINDOW.isVisible())
					if(buy == true)
						return OfferState.OFFER_SCREEN_TYPE_WRONG;
				
				//The type is correct, check if the item is correct
				if(GEInterfaces.OFFER_ITEM.get().getComponentItem() == itemID) {
					//The item is correct, check if the price is correct
					int currentPrice = InfoHelper.stringToInt(GEInterfaces.OFFER_PRICE.get().getText(), " coins",",");
					if(price == -1) {
						int avrPrice = InfoHelper.stringToInt(GEInterfaces.OFFER_AVR_PRICE.get().getText(), ",");
						if(buy == true) {
							Double targ = avrPrice * 1.2;
							int target = targ.intValue();
							if(currentPrice > target) {
								//The price is correct, check if the quantity is correct
								int currentQuantity = InfoHelper.stringToInt(GEInterfaces.OFFER_QUANTITY.get().getText(), ",");
								if(currentQuantity == quantity) {
									//The quantity is correct, return confirm offer
									return OfferState.OFFER_SCREEN_OFFER_CORRECT;
								} else {
									//No the quantity isn't correct, return quantity wrong
									return OfferState.OFFER_SCREEN_QUANTITY_WRONG;
								}
							} else {
								//the price is wrong
								return OfferState.OFFER_SCREEN_PRICE_WRONG;
							}
						} else {
							Double targ = avrPrice * 0.67;
							int target = targ.intValue();
							if(currentPrice < target) {
								//The price is correct, check if the quantity is correct
								int currentQuantity = InfoHelper.stringToInt(GEInterfaces.OFFER_QUANTITY.get().getText(), ",");
								if(currentQuantity == quantity) {
									//The quantity is correct, return confirm offer
									return OfferState.OFFER_SCREEN_OFFER_CORRECT;
								} else {
									//No the quantity isn't correct, return quantity wrong
									return OfferState.OFFER_SCREEN_QUANTITY_WRONG;
								}
							} else {
								//the price is wrong
								return OfferState.OFFER_SCREEN_PRICE_WRONG;
							}
						}
					} else if(currentPrice == price) {
						//The price is correct, check if the quantity is correct
						int currentQuantity = InfoHelper.stringToInt(GEInterfaces.OFFER_QUANTITY.get().getText(), ",");
						if(currentQuantity == quantity) {
							//The quantity is correct, return confirm offer
							return OfferState.OFFER_SCREEN_OFFER_CORRECT;
						} else {
							//No the quantity isn't correct, return quantity wrong
							return OfferState.OFFER_SCREEN_QUANTITY_WRONG;
						}
					} else {
						//No the price isn't correct, return price wrong
						return OfferState.OFFER_SCREEN_PRICE_WRONG;
					}
				} else {
					//The item isn't correct
					return OfferState.OFFER_SCREEN_ITEM_WRONG;
				}
			} else if(GEInterfaces.HISTORY_WINDOW.isVisible()){
				//We are on the history screen, return on history screen
				return OfferState.HISTORY_SCREEN;
			} else {
				return OfferState.LOADING_SCREENS;
			}
		} else {
			return OfferState.GE_CLOSED;
		}
	}
	
	public static enum QuantityState {
		PLUS_1000, PLUS_100, PLUS_10, PLUS_1, CUSTOM, PLUS, MINUS, CORRECT
	}

	/*public static QuantityState getQuantityState(int goal, int current) {
		if(goal == current)
			return QuantityState.CORRECT;
		if(goal > current + 998)
			return QuantityState.PLUS_1000;
		if(goal > current + 98)
			return QuantityState.PLUS_100;
		if(goal > current + 9)
			return QuantityState.PLUS_10;
		if(goal > current)
			return QuantityState.PLUS_1;
		if(goal + 10 < current)
			return QuantityState.CUSTOM;
		return QuantityState.MINUS;
	}WORKING METHOD */

	public static QuantityState getQuantityState(int goal, int current) {
		if(goal == current)
			return QuantityState.CORRECT;
		return QuantityState.CUSTOM;
	}

	public enum OfferState {
		 GE_CLOSED,
		 SELECTION_SCREEN_OFFER_ACTIVE,
		 SELECTION_SCREEN_CAN_MAKE_OFFER,
		 SELECTION_SCREEN_CAN_COLLECT,
		 SELECTION_SCREEN_SHOULD_RETURN_TRUE,
		 SELECTION_SCREEN_SHOULD_CANCEL_OFFER,
		 SELECTION_SCREEN_SHOULD_WAIT,
		 OFFER_SCREEN_TYPE_WRONG,
		 OFFER_SCREEN_ITEM_WRONG,
		 OFFER_SCREEN_PRICE_WRONG,
		 OFFER_SCREEN_QUANTITY_WRONG,
		 OFFER_SCREEN_OFFER_CORRECT,
		 HISTORY_SCREEN,
		 LOADING_SCREENS
	}
	
	public enum WindowState {
		CLOSED, SELECTION_SCREEN, BUY_SCREEN, SELL_SCREEN, HISTORY_SCREEN
	}
	
	public static WindowState getWindowState() {
		if(GEInterfaces.SELECTION_WINDOW.isVisible())
			return WindowState.SELECTION_SCREEN;
		
		if(GEInterfaces.HISTORY_WINDOW.isVisible())
			return WindowState.HISTORY_SCREEN;
		
		if(GEInterfaces.BUY_WINDOW.isVisible())
			return WindowState.BUY_SCREEN;
		
		if(GEInterfaces.SELL_WINDOW.isVisible())
			return WindowState.SELL_SCREEN;
		
		return WindowState.CLOSED;
	}
	
	public static void handleCancellingOffer() {
		for(int i = 7; i < 15 ; i++) {
			RSInterface type = Interfaces.get(465, i, 16);
			if(type != null && !type.isHidden()) {
				if(type.getText().contains("Sell")) {
					RSInterface slot = Interfaces.get(465, i, 2);
					if(slot != null && !slot.isHidden()) {
						if(slot.click("Abort offer")) {
							Timing.waitCondition(GEConditions.canCollect(), General.random(4000, 7000));
						}
					}
				}
			}
		}
	}
	
	public static void handleMakingOffer(String name, boolean buy) {
		if(buy == true) {
			for(int i = 7; i < 15 ; i++) {
				RSInterface type = Interfaces.get(465, i, 16);
				if(type != null && !type.isHidden()) {
					if(type.getText().contains("Empty")) {
						RSInterface buyBtn = Interfaces.get(465, i, 3);
						if(buyBtn != null && !buyBtn.isHidden()) {
							if(buyBtn.click()) {
								Timing.waitCondition(GEConditions.GEBuyWindowVisible(), General.random(4000, 7000));
							}
						}
					}
				}
			}
		} else {
			RSItem[] target = Inventory.find(name);
			if(target != null && target.length > 0) {
				if(target[0].click()) {
					Timing.waitCondition(GEConditions.GESellWindowVisible(), General.random(4000, 7000));
				}
			}
		}
	}
	
	public static void handleWrongOfferPrice(int price, boolean buy) {
		if(GEInterfaces.OFFER_AVR_PRICE.isVisible()) {
			if(price == -1) {
				if(buy == true) {
					GEInterfaces.PRICE_PLUS_5.get().click();
					return;
				} else {
					GEInterfaces.PRICE_MINUS_5.get().click();
					return;
				}
			}
		}
		
		if(GEInterfaces.SEARCH_ITEM_INPUT_TEXT.isVisible()) {
			Keyboard.typeSend(Integer.toString(price));
			Timing.waitCondition(GEConditions.GESearchBoxDissapeared(), General.random(4000, 7000));
			return;
		} 
		
		if(GEInterfaces.PRICE_CUSTOM.isVisible()) {
			if(GEInterfaces.PRICE_CUSTOM.get().click()) {
				Timing.waitCondition(GEConditions.GESearchBoxAppeared(), General.random(4000, 7000));
				return;
			}
		}
	}
	
	public static void handleWrongOfferQuantity(int quantity) {
		// quantity isn't correct
		if(GEInterfaces.SEARCH_ITEM_INPUT_QUAN.isVisible()) {
			//General.println("1");
			Keyboard.typeSend(Integer.toString(quantity));
			Timing.waitCondition(GEConditions.GESearchBoxDissapeared(), General.random(4000, 7000));
			return;
		}
		//General.println("2");
		int currentQuantity = InfoHelper.stringToInt(GEInterfaces.OFFER_QUANTITY.get().getText(), ",");
		//General.println("3");
		//General.println(currentQuantity);
		General.sleep(250);
		switch(getQuantityState(quantity, currentQuantity)) {
		case CORRECT:
			break;
		case CUSTOM:
			if(GEInterfaces.QUAN_CUSTOM.isVisible()) {
				//General.println("4");
				GEInterfaces.QUAN_CUSTOM.get().click();
				Timing.waitCondition(GEConditions.GESearchBoxAppeared(), General.random(4000, 7000));
			}
			break;
		case MINUS:
			if(GEInterfaces.QUAN_MINUS.isVisible())
				GEInterfaces.QUAN_MINUS.get().click();
			break;
		case PLUS:
			if(GEInterfaces.QUAN_PLUS.isVisible())
				GEInterfaces.QUAN_PLUS.get().click();
			break;
		case PLUS_1:
			if(GEInterfaces.QUAN_PLUS_1.isVisible())
				GEInterfaces.QUAN_PLUS_1.get().click();
			break;
		case PLUS_10:
			if(GEInterfaces.QUAN_PLUS_10.isVisible())
				GEInterfaces.QUAN_PLUS_10.get().click();
			break;
		case PLUS_100:
			if(GEInterfaces.QUAN_PLUS_100.isVisible())
				GEInterfaces.QUAN_PLUS_100.get().click();
			break;
		case PLUS_1000:
			if(GEInterfaces.QUAN_PLUS_1000.isVisible())
				GEInterfaces.QUAN_PLUS_1000.get().click();
			break;
		}
	}
	
	public static void handleWrongOfferItem(String name, int itemID, boolean buy) {
		if(buy == true) {
			//General.println("1");
			if(GEInterfaces.SEARCH_ITEM_INPUT_TEXT.isVisible()) {
				//General.println("2");
				if(GEInterfaces.SEARCH_ITEM_RESULTS_CONTAINER.isVisible()) 
				{
					if(hasSearchTarget(itemID, name, GEInterfaces.SEARCH_ITEM_INPUT_TEXT.get().getText().substring(46, 
							GEInterfaces.SEARCH_ITEM_INPUT_TEXT.get().getText().length()-1))) 
					{
						if(clickSearchTarget(itemID, name, GEInterfaces.SEARCH_ITEM_INPUT_TEXT.get().getText().substring(46, 
								GEInterfaces.SEARCH_ITEM_INPUT_TEXT.get().getText().length()-1)))  
						{
							//General.println("5");
							General.sleep(1300, 2100);
							return;
						}
					} 
					else {
							String alreadyTyped = GEInterfaces.SEARCH_ITEM_INPUT_TEXT.get().getText();
							String trimmed = alreadyTyped.substring(46, alreadyTyped.length()-1);
							if(trimmed.equalsIgnoreCase(name))
							{
								General.println("cant find item on GE");
								return;
							}
							Keyboard.typeString(InfoHelper.partNameToType(name, trimmed.replace("*", "")));
							alreadyTyped = GEInterfaces.SEARCH_ITEM_INPUT_TEXT.get().getText();
							trimmed = alreadyTyped.substring(46, alreadyTyped.length()-1);
							if(trimmed.charAt(0) != name.charAt(0))
								Keyboard.holdKey(KeyEvent.CHAR_UNDEFINED, KeyEvent.VK_BACK_SPACE, () -> 
								GEInterfaces.SEARCH_ITEM_INPUT_TEXT.get().getText().equalsIgnoreCase("<col=000000>What would you like to buy?</col> *"));
							General.sleep(600,900);
							return;
						}
					
				}
			}
			
			if(GEInterfaces.OFFER_ITEM.isVisible()) {
				if(GEInterfaces.OFFER_ITEM.get().click()) {
					Timing.waitCondition(GEConditions.GESearchBoxAppeared(), General.random(4000, 7000));
					return;
				}
			}
		} else {
			RSItem[] target = Inventory.find(itemID);
			if(target != null && target.length > 0) {
				if(target[0].click()) {
					General.sleep(900, 2100);
				}
			}
		}
	}
	
	public static boolean firstRow()
	{
		while(GEInterfaces.SEARCH_RESULT_10.get().getAbsolutePosition().y<(Screen.getDimension().height-130) || GEInterfaces.SEARCH_RESULT_10.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
		{
			if(GEInterfaces.SEARCH_RESULT_10.get().getAbsolutePosition().y<(Screen.getDimension().height-130))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_UP.get().click();
			}
			else if(GEInterfaces.SEARCH_RESULT_10.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_DOWN.get().click();
			}
		}
		return true;
	}

	public static boolean secondRow()
	{
		while(GEInterfaces.SEARCH_RESULT_13.get().getAbsolutePosition().y<(Screen.getDimension().height-130) || GEInterfaces.SEARCH_RESULT_13.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
		{
			if(GEInterfaces.SEARCH_RESULT_13.get().getAbsolutePosition().y<(Screen.getDimension().height-130))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_UP.get().click();
			}
			else if(GEInterfaces.SEARCH_RESULT_13.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_DOWN.get().click();
			}
		}
		return true;
	}

	public static boolean thirdRow()
	{
		while(GEInterfaces.SEARCH_RESULT_16.get().getAbsolutePosition().y<(Screen.getDimension().height-130) || GEInterfaces.SEARCH_RESULT_16.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
		{
			if(GEInterfaces.SEARCH_RESULT_16.get().getAbsolutePosition().y < (Screen.getDimension().height-130))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_UP.get().click();
			}
			else if(GEInterfaces.SEARCH_RESULT_16.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_DOWN.get().click();
			}
		}
		return true;
	}

	public static boolean fourthRow()
	{
		while(GEInterfaces.SEARCH_RESULT_19.get().getAbsolutePosition().y<(Screen.getDimension().height-130) || GEInterfaces.SEARCH_RESULT_19.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
		{
			if(GEInterfaces.SEARCH_RESULT_19.get().getAbsolutePosition().y<(Screen.getDimension().height-130))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_UP.get().click();
			}
			else if(GEInterfaces.SEARCH_RESULT_19.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_DOWN.get().click();
			}
		}
		return true;
	}

	public static boolean fifthRow()
	{
		while(GEInterfaces.SEARCH_RESULT_22.get().getAbsolutePosition().y<(Screen.getDimension().height-130) || GEInterfaces.SEARCH_RESULT_22.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
		{
			if(GEInterfaces.SEARCH_RESULT_22.get().getAbsolutePosition().y<(Screen.getDimension().height-130))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_UP.get().click();
			}
			else if(GEInterfaces.SEARCH_RESULT_22.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_DOWN.get().click();
			}
		}
		return true;
	}

	public static boolean sixthRow()
	{
		while(GEInterfaces.SEARCH_RESULT_25.get().getAbsolutePosition().y<(Screen.getDimension().height-130) || GEInterfaces.SEARCH_RESULT_25.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
		{
			if(GEInterfaces.SEARCH_RESULT_25.get().getAbsolutePosition().y<(Screen.getDimension().height-130))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_UP.get().click();
			}
			else if(GEInterfaces.SEARCH_RESULT_25.get().getAbsolutePosition().y>(Screen.getDimension().height-46))
			{
				General.sleep(250,500);
				GEInterfaces.SEARCH_ITEMS_RESULTS_DOWN.get().click();
			}
		}
		return true;
	}
	
	public static boolean hasSearchTarget(int itemID, String name, String trimmed) {
		if(GEInterfaces.SEARCH_RESULT_1.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_1.get().getComponentItem() == itemID) {
				return true;
			}
		}
		if(GEInterfaces.SEARCH_RESULT_2.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_2.get().getComponentItem() == itemID) {
				return true;
			}
		}
		if(GEInterfaces.SEARCH_RESULT_3.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_3.get().getComponentItem() == itemID) {
				return true;
			}
		}
		if(GEInterfaces.SEARCH_RESULT_4.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_4.get().getComponentItem() == itemID) {
				return true;
			}
		}
		if(GEInterfaces.SEARCH_RESULT_5.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_5.get().getComponentItem() == itemID) {
				return true;
			}
		}
		if(GEInterfaces.SEARCH_RESULT_6.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_6.get().getComponentItem() == itemID) {
				return true;
			}
		}
		if(GEInterfaces.SEARCH_RESULT_7.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_7.get().getComponentItem() == itemID) {
				return true;
			}
		}
		if(GEInterfaces.SEARCH_RESULT_8.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_8.get().getComponentItem() == itemID) {
				return true;
			}
		}
		if(GEInterfaces.SEARCH_RESULT_9.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_9.get().getComponentItem() == itemID) {
				return true;
			}
		}
		if(trimmed.equalsIgnoreCase(name))
		{
			if(GEInterfaces.SEARCH_RESULT_10.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_10.get().getComponentItem() == itemID) {
					return firstRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_11.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_11.get().getComponentItem() == itemID) {
					return firstRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_12.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_12.get().getComponentItem() == itemID) {
					return firstRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_13.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_13.get().getComponentItem() == itemID) {
					return secondRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_14.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_14.get().getComponentItem() == itemID) {
					return secondRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_15.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_15.get().getComponentItem() == itemID) {
					return secondRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_16.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_16.get().getComponentItem() == itemID) {
					return thirdRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_17.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_17.get().getComponentItem() == itemID) {
					return thirdRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_18.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_18.get().getComponentItem() == itemID) {
					return thirdRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_19.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_19.get().getComponentItem() == itemID) {
					return fourthRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_20.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_20.get().getComponentItem() == itemID) {
					return fourthRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_21.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_21.get().getComponentItem() == itemID) {
					return fourthRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_22.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_22.get().getComponentItem() == itemID) {
					return fifthRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_23.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_23.get().getComponentItem() == itemID) {
					return fifthRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_24.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_24.get().getComponentItem() == itemID) {
					return fifthRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_25.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_25.get().getComponentItem() == itemID) {
					return sixthRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_26.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_26.get().getComponentItem() == itemID) {
					return sixthRow();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_27.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_27.get().getComponentItem() == itemID) {
					return sixthRow();
				}
			}
		}
		return false;
	}
	
	public static boolean clickSearchTarget(int itemID, String name, String trimmed) {
		if(GEInterfaces.SEARCH_RESULT_1.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_1.get().getComponentItem() == itemID) {
				return GEInterfaces.SEARCH_RESULT_1.get().click();
			}
		}
		if(GEInterfaces.SEARCH_RESULT_2.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_2.get().getComponentItem() == itemID) {
				return GEInterfaces.SEARCH_RESULT_2.get().click();
			}
		}
		if(GEInterfaces.SEARCH_RESULT_3.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_3.get().getComponentItem() == itemID) {
				return GEInterfaces.SEARCH_RESULT_3.get().click();
			}
		}
		if(GEInterfaces.SEARCH_RESULT_4.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_4.get().getComponentItem() == itemID) {
				return GEInterfaces.SEARCH_RESULT_4.get().click();
			}
		}
		if(GEInterfaces.SEARCH_RESULT_5.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_5.get().getComponentItem() == itemID) {
				return GEInterfaces.SEARCH_RESULT_5.get().click();
			}
		}
		if(GEInterfaces.SEARCH_RESULT_6.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_6.get().getComponentItem() == itemID) {
				return GEInterfaces.SEARCH_RESULT_6.get().click();
			}
		}
		if(GEInterfaces.SEARCH_RESULT_7.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_7.get().getComponentItem() == itemID) {
				return GEInterfaces.SEARCH_RESULT_7.get().click();
			}
		}
		if(GEInterfaces.SEARCH_RESULT_8.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_8.get().getComponentItem() == itemID) {
				return GEInterfaces.SEARCH_RESULT_8.get().click();
			}
		}
		if(GEInterfaces.SEARCH_RESULT_9.isVisible()) {
			if(GEInterfaces.SEARCH_RESULT_9.get().getComponentItem() == itemID) {
				return GEInterfaces.SEARCH_RESULT_9.get().click();
			}
		}
		if(trimmed.equalsIgnoreCase(name))
		{
			if(GEInterfaces.SEARCH_RESULT_10.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_10.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_10.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_11.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_11.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_11.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_12.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_12.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_12.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_13.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_13.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_13.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_14.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_14.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_14.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_15.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_15.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_15.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_16.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_16.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_16.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_17.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_17.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_17.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_18.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_18.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_18.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_19.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_19.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_19.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_20.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_20.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_20.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_21.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_21.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_21.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_22.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_22.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_22.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_23.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_23.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_23.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_24.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_24.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_24.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_25.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_25.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_25.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_26.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_26.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_26.get().click();
				}
			}
			if(GEInterfaces.SEARCH_RESULT_27.isVisible()) {
				if(GEInterfaces.SEARCH_RESULT_27.get().getComponentItem() == itemID) {
					return GEInterfaces.SEARCH_RESULT_27.get().click();
				}
			}
		}
		return false;
	}
	
	public static void exitHistoryScreen() {
		if(GEInterfaces.EXCHANGE_BTN.isVisible()) {
			if(GEInterfaces.EXCHANGE_BTN.get().click()) {
				Timing.waitCondition(GEConditions.GESelectionWindowVisible(), General.random(4000, 7000));
			}
		}
	}
	
	public static boolean isOpen() {
		return GEInterfaces.MASTER.isVisible() || GEInterfaces.HISTORY_WINDOW.isVisible();
	}
	
	public static boolean open() {
		if(isOpen()) return true;
		
		RSNPC[] geClerks = NPCs.findNearest("Grand Exchange Clerk");
		if (geClerks.length > 0)
			if(Clicking.click("Exchange Grand Exchange Clerk", geClerks[0])) 
				Timing.waitCondition(GEConditions.GEOpen(), General.random(3000, 7000));
				return isOpen();
	}

}
