package scripts.api.GrandExchangeSnippet;

//ORIGINAL CREDITS TO NEURO - https://tribot.org/forums/topic/78027-snippets-neuros-ge-api/


//CHANGED BROKEN INTERFACEIDS





public class GEConditions {

	public static Condition hasCollected() {
		return new Condition(() -> !GEInterfaces.COLLECT_BTN.isVisible());
	}
	
	public static Condition canCollect() {
		return new Condition(() -> GEInterfaces.COLLECT_BTN.isVisible());
	}
	
	public static Condition GEOpen() {
		return new Condition(() -> Exchange.isOpen());
	}
	
	public static Condition GEClosed() {
		return new Condition(() -> !Exchange.isOpen());
	}
	
	public static Condition GEBuyWindowVisible() {
		return new Condition(() -> GEInterfaces.BUY_WINDOW.isVisible());
	}
	
	public static Condition GESellWindowVisible() {
		return new Condition(() -> GEInterfaces.SELL_WINDOW.isVisible());
	}
	
	public static Condition GESelectionWindowVisible() {
		return new Condition(() -> GEInterfaces.SELECTION_WINDOW.isVisible());
	}
	
	public static Condition GESearchBoxDissapeared() {
		return new Condition(() -> !GEInterfaces.SEARCH_ITEM_INPUT_TEXT.isVisible());
	}
	
	public static Condition GESearchBoxAppeared() {
		return new Condition(() -> GEInterfaces.SEARCH_ITEM_INPUT_TEXT.isVisible());
	}
	
	private interface BooleanLambda{
        boolean active();
    }

    private static class Condition extends org.tribot.api.types.generic.Condition{
        private BooleanLambda lambda;

        public Condition(BooleanLambda lambda){
            super();
            this.lambda = lambda;
        }

        @Override
        public boolean active() {
            return lambda.active();
        }
    }
	
}