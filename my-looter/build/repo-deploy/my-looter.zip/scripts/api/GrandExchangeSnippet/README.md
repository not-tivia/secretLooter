# Grand Exchange API
2019-11-19 Added more humanlike item searching, as well as more humanlike quantity and price adjustment.

2019-11-07 Added more GE interfaces for searching, fixed search to be able to find items not on the first page of 9 results, added failsafe for typing item name (used to start tpying before GE opened and would get stuck in a loop)

Buy, sell, and collect with all necessary checks.
Still in the proccess of verifying all Interfaces IDS as some have changed and split.
So far buying and selling seems to be working properly now.
forked from Neuro's GE Snippet https://tribot.org/forums/topic/78027-snippets-neuros-ge-api/
