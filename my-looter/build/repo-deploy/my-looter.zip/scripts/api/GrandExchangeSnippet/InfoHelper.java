package scripts.api.GrandExchangeSnippet;

//ORIGINAL CREDITS TO NEURO - https://tribot.org/forums/topic/78027-snippets-neuros-ge-api/


//CHANGED BROKEN INTERFACEIDS


import org.tribot.api.General;
import org.tribot.api2007.types.RSItemDefinition;

public class InfoHelper {

	public static int stringToInt(String input, String... toRemove) {
		String[] forRemoving = toRemove;
		switch(forRemoving.length) {
		case 1:
			return Integer.parseInt(input.replace(forRemoving[0], ""));
		case 2:
			String first = input.replace(forRemoving[0], "");
			return Integer.parseInt(first.replace(forRemoving[1], ""));
		case 3:
			String first2 = input.replace(forRemoving[0], "");
			String second = first2.replace(forRemoving[1], "");
			return Integer.parseInt(second.replace(forRemoving[2], ""));
		default:
			return -1;
		}
	}

	/*public static String partNameToType(String fullName, String alreadyTyped) {
		String remaining = fullName.replaceFirst(alreadyTyped, "");
		int rand = General.random(remaining.length()/3, remaining.length());
		return remaining.length() > 2 ? remaining.substring(0, rand) : remaining;
	}old wokring method*/

	public static String partNameToType(String fullName, String alreadyTyped) {
		String remaining = fullName.replaceFirst(alreadyTyped, "");
		int rand;
		if(remaining.length()>10)
			rand = General.random(3, 5);
		else
			rand = General.random(remaining.length()/3, remaining.length());
		return remaining.length() > 2 ? remaining.substring(0, rand) : remaining;
	}
	
	public static String getItemNameFromID(int itemID){
        RSItemDefinition itemDef  = RSItemDefinition.get(itemID);
        if(itemDef !=null){
            String itemName = itemDef.getName();
            if(itemName!=null){
                return itemName;
            }
        }
        return "";
	}
	
}
