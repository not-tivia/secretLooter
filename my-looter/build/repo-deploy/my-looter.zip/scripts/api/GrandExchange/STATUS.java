package scripts.api.GrandExchange;

/**
 * STATUS represents the three possible statuses of a Grand Exchange offer.
 */
public enum STATUS {

	COMPLETE, IN_PROGRESS, ABORTED, NOT_USING, AVAILABLE_FOR_COLLECTION;

}