package scripts.api.pattern;

/**
 * Created by Spencer on 9/29/2017.
 */
public interface Equalable {

    boolean is(Object obj);

}
