package scripts.api.pattern;

/**
 * Created by Spencer on 8/11/2016.
 */
public interface BaseScript {
    void setStatus(String status);
    void update(String message);
}
