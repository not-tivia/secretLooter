package scripts.api.pattern;


/**
 * @author Laniax
 */
public interface BooleanLambda {
    boolean active();
}
