package scripts.api.pattern;

/**
 * Created by Spencer on 9/17/2017.
 */
public interface Consumable {

    void consume();

}
