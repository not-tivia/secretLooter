package scripts.api.items;

import org.tribot.api2007.Banking;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.ext.Filters;

import java.util.Arrays;

public class ItemCheck {

    public static boolean bankHasItem(String itemName) {
        return Banking.find(itemName).length > 0;
    }

    public static boolean bankHasAny(String... itemNames) {
        return Arrays.stream(itemNames).anyMatch(ItemCheck::bankHasItem);
    }


    public static boolean bankHasItemFilter (String itemName){
        return Banking.find(Filters.Items.nameContains(itemName)).length > 0;
    }

    public static boolean bankHasAnyFilter(String... itemNames) {
        return Arrays.stream(itemNames).anyMatch(ItemCheck::bankHasItemFilter);
    }

    public static boolean hasItem (String itemName){
        return Inventory.find(itemName).length > 0;
    }

    public static boolean hasAnyItem(String... itemNames) {
        return Arrays.stream(itemNames).anyMatch(ItemCheck::hasItem);
    }


    public static boolean hasItemFilter (String itemName){
        return Inventory.find(Filters.Items.nameContains(itemName)).length > 0;
    }

    public static boolean hasAnyItemFilter (String... itemNames){
        return Arrays.stream(itemNames).anyMatch(ItemCheck::hasItemFilter);
    }

    public static int hasItemStack(String itemName){
        return Inventory.find(itemName)[0].getStack();
    }








}
