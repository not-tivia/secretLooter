package scripts.api.interaction;

import org.tribot.api.Clicking;
import org.tribot.api.DynamicClicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.types.generic.Condition;
import org.tribot.api2007.*;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.*;
import scripts.api.dax_api.api_lib.DaxWalker;

public class Interactions {


    public static boolean interactWithNPC(String clickingAction, String npcName, RSArea npcArea) {
        if (!Player.isMoving()) {
            RSNPC[] npc = NPCs.findNearest(Filters.NPCs.inArea(npcArea).and(Filters.NPCs.nameEquals(npcName).and(Filters.NPCs.actionsContains(clickingAction))));
            if (npc.length > 0 && npc[0] != null) {
                if (npc[0].isOnScreen() && npc[0].isClickable()) {
                    if (PathFinding.canReach(npc[0].getPosition(), false)) {
                        if (clickingAction.equals("Attack")) {
                            if (npc[0].getHealthPercent() > 0) {
                                return Clicking.click(clickingAction, npc[0]);
                            }
                        } else {
                            return Clicking.click(clickingAction, npc[0]);
                        }

                    } else {
                        if (DaxWalker.walkTo(npc[0].getPosition())) {
                            Timing.waitCondition(() -> !Player.isMoving(), General.random(2300, 3100));
                        }
                    }
                } else {
                    if (npc[0].adjustCameraTo()) {
                        Timing.waitCondition(() -> !npc[0].isOnScreen() && !npc[0].isClickable(), General.random(2300, 3100));
                    }
                }
            } else {
                if (npcArea == null) {
                    General.println("Generating a 20x20 area around us");
                    RSArea someRandomArea = new RSArea(new RSTile(Player.getPosition().getY() + 20, Player.getPosition().getX() + 20), new RSTile(Player.getPosition().getY() - 20, Player.getPosition().getX() - 20));
                    if (DaxWalker.walkTo(someRandomArea.getRandomTile())) {
                        Timing.waitCondition(() -> !Player.isMoving(), General.random(2300, 3100));
                    }
                } else {
                    if (DaxWalker.walkTo(npcArea.getRandomTile())) {
                        Timing.waitCondition(() -> !Player.isMoving(), General.random(2300, 3100));
                    }
                }

            }
        }
        return false;
    }



    public static boolean interactWithObject(String clickingAction, String objName, RSArea npcArea) {
        if ( !Player.isMoving()) {
            RSObject[] obj = Objects.findNearest(20, Filters.Objects.inArea(npcArea).and(Filters.Objects.nameEquals(objName).and(Filters.Objects.actionsContains(clickingAction))));
            if (obj.length > 0 && obj[0] != null) {
                if (obj[0].isOnScreen() && obj[0].isClickable()) {
                    if (PathFinding.canReach(obj[0].getPosition(), true)) {
                        if (obj[0].click(clickingAction))
                            General.sleep(1200, 3000);
                            return true;

                    } else {
                        if (DaxWalker.walkTo(obj[0].getPosition())) {
                            Timing.waitCondition(() -> !Player.isMoving(), General.random(2300, 3100));
                        }
                    }
                } else {
                    if (obj[0].adjustCameraTo()) {
                        Timing.waitCondition(() -> !obj[0].isOnScreen() && !obj[0].isClickable(), General.random(2300, 3100));
                    }
                }
            } else {
                if (npcArea == null) {
                    General.println("Generating a 20x20 area around us");
                    RSArea someRandomArea = new RSArea(new RSTile(Player.getPosition().getY() + 20, Player.getPosition().getX() + 20), new RSTile(Player.getPosition().getY() - 20, Player.getPosition().getX() - 20));
                    if (DaxWalker.walkTo(someRandomArea.getRandomTile())) {
                        Timing.waitCondition(() -> !Player.isMoving(), General.random(2300, 3100));
                    }
                } else {

                    if (DaxWalker.walkTo(npcArea.getRandomTile())) {
                        Timing.waitCondition(() -> !Player.isMoving(), General.random(2300, 3100));
                    }
                }

            }
        }
        return false;
    }


    public static boolean useItemOnNPC(String itemName, String NPC){
        RSItem[] item = Inventory.find(itemName);
        RSNPC[] npc = NPCs.find(NPC);
        if (item.length > 0 && item[0] != null) {
            if (Clicking.click("Use",item[0])) {
                Timing.waitCondition(new Condition() {
                    @Override
                    public boolean active() {
                        return Game.getUptext().equals("Use " + item);
                    }
                }, General.random(300, 900));
            }
        }
        if (npc.length > 0 && npc[0] != null) {
            if (DynamicClicking.clickRSNPC(npc[0], "Use")){

                General.sleep(600,1700);
                return true;
            }


        }
        return false;
    }

    public static boolean useItemOnItem(String itemName, String itemName2){
        RSItem[] item = Inventory.find(itemName);
        RSItem[] item2 = Inventory.find(itemName2);
        if (item.length > 0 && item[0] != null) {
            if (Clicking.click("Use",item[0])) {
                Timing.waitCondition(new Condition() {
                    @Override
                    public boolean active() {
                        return Game.getUptext().equals("Use " + item);
                    }
                }, General.random(300, 900));
            }
        }
        if (item2.length > 0 &&item2[0] != null) {
            if (Clicking.click( "Use", item2[0])){

                General.sleep(1300,2700);
                return true;
            }


        }
        return false;
    }

    public static void useItemOnObj(String itemName, String target){
        RSItem[] item = Inventory.find(itemName);
        if (item.length > 0 && item[0] != null) {
            if (item[0].click("Use")) {
                Timing.waitCondition(() -> Game.getUptext() != null && Game.getUptext().contains("Use " + itemName + " -> "),General.random(3000, 4000));
            }
        }
        General.sleep(50, 100);
        RSObject[] object = Objects.findNearest(20, target);
        if (object.length > 0 && object[0] != null){
            if (object[0].isOnScreen() && object[0].isClickable()) {
                if (object[0].click("Use " + itemName + " -> " + target))
                    Timing.waitCondition(() -> Player.getAnimation() != -1, General.random(3000, 4000));
            } else {
                object[0].adjustCameraTo();
                General.sleep(100,300);
            }
        }
    }

    public static void useItem(String itemName, String target) {
        RSItem[] item = Inventory.find(itemName);
        if (item.length > 0) {
            if (item[0].click("Use")) {
                Timing.waitCondition(() -> Game.getUptext() != null && Game.getUptext().contains("Use " + itemName + " -> "), General.random(3000, 4000));
            }
        }
        General.sleep(50, 100);
        RSObject[] object = Objects.findNearest(20, target);
        if (object.length > 0) {
            if (object[0].click("Use " + itemName + " -> " + target))
                Timing.waitCondition(() -> Player.getAnimation() != -1, General.random(3000, 4000));
        }
    }

    public boolean isFighting(){
        RSCharacter ch = Player.getRSPlayer().getInteractingCharacter();
        if (ch != null && ch.getPosition().distanceTo(Player.getPosition()) <= 4 && ch.isInCombat()){
            if (Timing.waitCondition(() -> ch != null && ch.getPosition().distanceTo(Player.getPosition()) <= 4 && ch.isInCombat(), General.random(2000, 3000))){
                return true;
            }
        }
        return false;

    }

    public static void navigateToEntitiy(String entityName, String entityType, String entityAction, RSTile tileInTheWay, String objectAction){
        if (entityType.equals("obj")){
            RSObject[] name = Objects.find(20, entityName);
            if (PathFinding.canReach(name[0], true)){
                if (name[0].isClickable() && name[0].isOnScreen()){
                    if (Clicking.click(entityAction, name[0])){
                        General.sleep(1500,2000);
                    }
                } else {
                    if (name[0].adjustCameraTo()){
                        Timing.waitCondition(() -> name[0].isClickable() && name[0].isOnScreen(), General.random(2300, 3100));
                    }
                }

            } else {
                General.println("cannot reach " +entityName);
                RSObject[] obj = Objects.find(15, Filters.Objects.tileEquals(tileInTheWay).and(Filters.Objects.actionsContains(objectAction)));
                if (obj.length > 0 && obj[0].isClickable() && obj[0].isOnScreen()){
                    if (Clicking.click(objectAction, obj[0])){
                        General.sleep(2100,5000);
                    }
                } else {
                    if (obj[0].adjustCameraTo()){
                        Timing.waitCondition(() -> obj[0].isClickable() && obj[0].isOnScreen(), General.random(2300, 3100));
                    }
                }
            }
        } else if (entityType.equals("npc")){
            RSNPC[] name = NPCs.findNearest(entityName);
            if (PathFinding.canReach(name[0], true)){
                if (name[0].isClickable() && name[0].isOnScreen()){
                    if (Clicking.click(entityAction, name[0])){
                        General.sleep(1500,2000);
                    }
                } else {
                    if (name[0].adjustCameraTo()){
                        Timing.waitCondition(() -> name[0].isClickable() && name[0].isOnScreen(), General.random(2300, 3100));
                    }
                }
            } else {
                General.println("cannot reach " +entityName);
                RSObject[] obj = Objects.find(15, Filters.Objects.tileEquals(tileInTheWay).and(Filters.Objects.actionsContains(objectAction)));
                if (obj.length > 0 && obj[0].isClickable() && obj[0].isOnScreen()){
                    if (Clicking.click(objectAction, obj[0])){
                        General.sleep(2100,5000);
                    }
                } else {
                    if (obj[0].adjustCameraTo()){
                        Timing.waitCondition(() -> obj[0].isClickable() && obj[0].isOnScreen(), General.random(2300, 3100));
                    }
                }

            }
        } else if (entityType.equals("item")){
            RSGroundItem[] name = GroundItems.find(entityName);
            if (PathFinding.canReach(name[0], true)){
                if (name[0].isClickable() && name[0].isOnScreen()){
                    if (Clicking.click(entityAction, name[0])){
                        General.sleep(1500,2000);
                    }
                } else {
                    if (name[0].adjustCameraTo()){
                        Timing.waitCondition(() -> name[0].isClickable() && name[0].isOnScreen(), General.random(2300, 3100));
                    }
                }
            } else {
                General.println("cannot reach " +entityName);
                RSObject[] obj = Objects.find(15, Filters.Objects.tileEquals(tileInTheWay).and(Filters.Objects.actionsContains(objectAction)));
                if (obj.length > 0 && obj[0].isClickable() && obj[0].isOnScreen()){
                    if (Clicking.click(objectAction, obj[0])){
                        General.sleep(2100,5000);
                    }
                } else {
                    if (obj[0].adjustCameraTo()){
                        Timing.waitCondition(() -> obj[0].isClickable() && obj[0].isOnScreen(), General.random(2300, 3100));
                    }
                }
            }
        }



    }

    public static boolean takeGroundItem(String itemName){
        RSGroundItem[] floormeat = GroundItems.findNearest(Filters.GroundItems.nameContains(itemName));
        if (floormeat.length > 0 && floormeat[0]!=null) {
            if (floormeat[0].isClickable() && floormeat[0].isOnScreen()) {
                if (floormeat[0].getDefinition()!=null && Clicking.click("Take " + floormeat[0].getDefinition().getName(), floormeat[0])) {
                    General.sleep(2100, 4210);
                    return true;
                }
            } else {
                floormeat[0].adjustCameraTo();
                General.sleep(2100, 4210);
            }
        }
        return false;
    }

    public static boolean takeObject(String clickOption, String itemName){
        RSObject[] floormeat = Objects.findNearest(15, Filters.Objects.nameContains(itemName));
        if (floormeat.length > 0 && floormeat[0]!=null) {
            if (floormeat[0].isClickable() && floormeat[0].isOnScreen()) {
                if (floormeat[0].getDefinition()!=null && Clicking.click(clickOption +" " + floormeat[0].getDefinition().getName(), floormeat[0])) {
                    General.sleep(2100, 4210);
                    return true;
                }
            } else {
                floormeat[0].adjustCameraTo();
                General.sleep(2100, 4210);
            }
        }
        return false;
    }



}
